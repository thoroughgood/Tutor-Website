# Frontend

To install dependencies run `npm i`

To start the frontend dev server run `npm run dev`

## Eslint and Prettier

We will use Eslint and Prettier to maintain consistent code style and linting.
Please ensure all code is linted and formatted before pushing to `main`
