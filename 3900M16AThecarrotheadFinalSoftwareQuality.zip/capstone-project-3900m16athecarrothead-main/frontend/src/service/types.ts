// types.ts contains useful types common between API calls
export interface SuccessResponse {
  success: boolean
}
