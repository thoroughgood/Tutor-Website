-- AlterTable
ALTER TABLE "Notification" ALTER COLUMN "messageId" DROP NOT NULL,
ALTER COLUMN "appointmentId" DROP NOT NULL;
