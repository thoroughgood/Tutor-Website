-- DropIndex
DROP INDEX "Message_sentById_appointmentId_key";

-- DropIndex
DROP INDEX "Message_sentById_directMessageId_key";
