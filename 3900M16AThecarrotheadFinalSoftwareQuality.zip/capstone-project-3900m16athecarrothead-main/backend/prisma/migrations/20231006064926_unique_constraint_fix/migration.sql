-- DropIndex
DROP INDEX "Appointment_studentId_key";

-- DropIndex
DROP INDEX "Appointment_tutorId_key";

-- DropIndex
DROP INDEX "Rating_createdById_key";

-- DropIndex
DROP INDEX "Rating_tutorId_key";

-- DropIndex
DROP INDEX "TutorAvailability_tutorId_key";
