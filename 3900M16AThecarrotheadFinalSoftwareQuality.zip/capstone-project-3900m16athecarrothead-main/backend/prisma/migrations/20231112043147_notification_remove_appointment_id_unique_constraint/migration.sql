-- DropIndex
DROP INDEX "Notification_appointmentId_key";

-- DropIndex
DROP INDEX "Notification_appointmentId_userId_key";

-- DropIndex
DROP INDEX "Notification_messageId_userId_key";
